import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, DollarSign, MessageSquareText } from "lucide-react";

export default function ReviewSellingSite() {
  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-10">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-4xl font-bold mb-4">Buy Reviews for Any Platform</h1>
        <p className="text-lg text-gray-600 mb-6">
          We offer 5-star reviews for Google, Facebook, Trustpilot, Yelp, and more — just $10 each!
        </p>

        <div className="flex justify-center gap-4 flex-wrap">
          <Card className="w-72 shadow-md">
            <CardContent className="p-4">
              <DollarSign className="text-blue-500 mb-2 mx-auto" size={32} />
              <h2 className="text-xl font-semibold mb-2">Fixed Price</h2>
              <p>$10 per review for all platforms</p>
            </CardContent>
          </Card>

          <Card className="w-72 shadow-md">
            <CardContent className="p-4">
              <Phone className="text-green-500 mb-2 mx-auto" size={32} />
              <h2 className="text-xl font-semibold mb-2">Order via WhatsApp</h2>
              <p>Quick orders & support directly on WhatsApp</p>
            </CardContent>
          </Card>

          <Card className="w-72 shadow-md">
            <CardContent className="p-4">
              <MessageSquareText className="text-purple-500 mb-2 mx-auto" size={32} />
              <h2 className="text-xl font-semibold mb-2">Multiple Payments</h2>
              <p>Easypaisa, JazzCash, PayPal, Crypto, Bank Transfer</p>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8">
          <Button size="lg" className="bg-green-600 text-white hover:bg-green-700">
            <a href="https://wa.me/923166719061" target="_blank" rel="noopener noreferrer">
              Order Now on WhatsApp
            </a>
          </Button>
        </div>

        {/* FAQ Section */}
        <div className="mt-16 text-left">
          <h2 className="text-2xl font-bold mb-4 text-center">Frequently Asked Questions</h2>
          <div className="space-y-6 max-w-3xl mx-auto">
            <div>
              <h3 className="font-semibold text-lg">🔒 Is this safe for my profile or business?</h3>
              <p className="text-gray-600">Yes! We use real accounts, unique IPs, and secure methods to avoid detection or removal.</p>
            </div>

            <div>
              <h3 className="font-semibold text-lg">⏱️ How long does it take to receive reviews?</h3>
              <p className="text-gray-600">Most reviews are delivered within 24–72 hours after payment confirmation.</p>
            </div>

            <div>
              <h3 className="font-semibold text-lg">💳 What payment methods are accepted?</h3>
              <p className="text-gray-600">We accept Easypaisa, JazzCash, PayPal, Crypto, and Bank Transfers.</p>
            </div>

            <div>
              <h3 className="font-semibold text-lg">📞 How can I get support or track my order?</h3>
              <p className="text-gray-600">You can contact us anytime on WhatsApp at +92 316 6719061 for updates or questions.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}